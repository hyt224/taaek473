def Start(): #실행 및 진행 함수

    label1.config(image='', text='주어지는 질문에 답하고 다음 버튼을 눌러주세요.', height=10)
    button_start.destroy() #안내 메세지 표시 및 시작 버튼 제거

    global question
    global question1
    global question2

    question = ['처음 만난 사람한테 먼저 말을 거는 편이다.','주로 사람들을 만나면 에너지를 얻는 편이다.','새로운 것을 접할 때, 먼저 경험해보고 이해하는 편이다.',
    '주로 자신의 감정을 타인에게 드러내는 편이다.','주로 어떠한 상황에 영향을 받기보다 주는 편이다.','타인의 관심을 받는 것을 즐긴다.','남들 앞에서 자신에 대해 표현하는 것을 좋아하는 편이다.',
    '생각보다 행동이 앞서는 편이다.','생각을 밖으로 드러내는 편이다.','여럿이서 일을 할 때 자신이 주도하는 것을 선호하는 편이다.','회의를 할 때 다른 사람의 말을 듣기보다 자신의 주장을 강하게 내세우는 편이다.',
    '주로 감정적이기보다 이성적인 편이다.','문제 상황이 발생하면 당사자의 입장에서 문제를 바라보기보다 상황 자체를 객관적으로 보는 편이다.','고집이 세다는 말을 자주 듣는다.',
    '자신이 옳다고 생각하면 그대로 추진한다.','뒤끝이나 복수심이 강한 편이다.','평소에 상상력이 풍부하며 낭만을 쫓는 경향이 있다.','꿈보다는 현실이 더 중요하다고 생각한다.','불의를 보면 참지 못하는 편이다.',
    '친구가 고민을 얘기하면 공감보다는 해결책을 제시해주는 편이다.','원칙을 지키는 것이 무엇보다도 중요하다고 생각한다.','나는 억울한 일을 겪었을 때 바로 해명하지 않는다.','슬픈 영화를 보면 눈물을 참지 못한다.'] #전체 질문
    
    question1 = ['처음 만난 사람한테 먼저 말을 거는 편이다.','주로 사람들을 만나면 에너지를 얻는 편이다.','새로운 것을 접할 때, 먼저 경험해보고 이해하는 편이다.',
    '주로 자신의 감정을 타인에게 드러내는 편이다.','주로 어떠한 상황에 영향을 받기보다 주는 편이다.','타인의 관심을 받는 것을 즐긴다.','남들 앞에서 자신에 대해 표현하는 것을 좋아하는 편이다.',
    '생각보다 행동이 앞서는 편이다.','생각을 밖으로 드러내는 편이다.','여럿이서 일을 할 때 자신이 주도하는 것을 선호하는 편이다.'] #외향/내향형 관련 질문
    
    question2 = ['회의를 할 때 다른 사람의 말을 듣기보다 자신의 주장을 강하게 내세우는 편이다.','주로 감정적이기보다 이성적인 편이다.',
    '문제 상황이 발생하면 당사자의 입장에서 문제를 바라보기보다 상황 자체를 객관적으로 보는 편이다.','고집이 세다는 말을 자주 듣는다.','자신이 옳다고 생각하면 그대로 추진한다.','뒤끝이나 복수심이 강한 편이다.',
    '평소에 상상력이 풍부하며 낭만을 쫓는 경향이 있다.','꿈보다는 현실이 더 중요하다고 생각한다.','불의를 보면 참지 못하는 편이다.','친구가 고민을 얘기하면 공감보다는 해결책을 제시해주는 편이다.',
    '원칙을 지키는 것이 무엇보다도 중요하다고 생각한다.','나는 억울한 일을 겪었을 때 바로 해명하지 않는다.','슬픈 영화를 보면 눈물을 참지 못한다.'] #계절 관련 질문

    global score1
    global score2
    global score1_how
    global score2_how
    score1 = 0
    score2 = 0
    score1_how = 0
    score2_how = 0 #A 및 B 관련 점수 변수 설정

    global button_go
    button_go = Button(test, text='다음', font=('Nanum Gothic', 20), relief='sunken', width=6, height=2, fg='maroon', command=Start_qus)
    button_go.place(x=0, y=400, relx=0.5, anchor='center') #진행 버튼

def Start_qus(): #질문 및 선택 버튼 표시 함수
    global rd1
    global rd2
    global rd3
    global rd4
    global rd5
    global score
    global qus
    global score1_how
    global score2_how

    score = IntVar() #선택 버튼값을 받는 변수 설정
    score.set(5)
        
    rd1 = Radiobutton(test, text='매우 그렇다', value=5, variable=score)
    rd2 = Radiobutton(test, text='그렇다', value=4, variable=score)
    rd3 = Radiobutton(test, text='보통이다', value=3, variable=score)
    rd4 = Radiobutton(test, text='그렇지 않다', value=2, variable=score)
    rd5 = Radiobutton(test, text='매우 그렇지 않다', value=1, variable=score)
    rd1.place(x=0, y=230, relx=0.35, anchor='w')
    rd2.place(x=0, y=255, relx=0.35, anchor='w')
    rd3.place(x=0, y=280, relx=0.35, anchor='w')
    rd4.place(x=0, y=305, relx=0.35, anchor='w')
    rd5.place(x=0, y=330, relx=0.35, anchor='w') #선택 버튼 생성

    qus = random.choice(question)
    label1.config(text=qus)

    if qus in question1:
        score1_how += 1
    elif qus in question2:
        score2_how += 1 #질문 중 랜덤 택일하여 출력하고 관련 질문에 따라 횟수 추가

    button_go.config(command=Cal_score) #진행 버튼 누르면 점수 계산 함수 호출

def Cal_score(): #점수 계산 함수
    global score1
    global score2
    global qus
    global score1_how
    global score2_how

    if (score1_how == 8) and (score2_how == 8):

        grade = score.get()
        grade = int(grade) #선택 버튼 값 받아서 정수로 변환

        if qus in question1:
            score1 += grade #질문이 A 관련일 경우 A 관련 점수에 선택 버튼 값 더하기
        elif qus in question2:
            score2 += grade #질문이 B 관련일 경우 B 관련 점수에 선택 버튼 값 더하기

        button_go.destroy()
        rd1.destroy()
        rd2.destroy()
        rd3.destroy()
        rd4.destroy()
        rd5.destroy()
        label1.destroy() #화면에서 위젯 제거

        result_message1 = '''당신은 마음이 따뜻한 사람! 당신은 타인에 대한 배려심이 높은 편이에요. 그래서 많은 사람들의 호감을 삽니다. 
이성적이기보다 감정적인 당신은 객관적인 논리나 사실보다 상대방의 의견에 더 큰 가치를 둬요. 그렇기 때문에 주변에서 우유부단하다는 말을 듣기도 한답니다. 
타인의 의견에 순종적이라 손해를 볼 수도 있으니 자기 주장이 필요할 땐 주저하지 말고 나서보세요!'''

        result_message2 = '''당신은 마음이 따뜻한 사람! 당신은 타인에 의한 배려심을 주저 없이 드러내고, 누구와도 쉽게 어울려요. 당신이 있는 곳이 곧 사교의 장이 되죠. 
바로바로 눈에 띄는 따뜻함에 많은 사람의 호감을 사지만, 정작 당신의 의견은 뒤로 감출 때가 많아요. 특유의 활발한 성격으로 자신의 의견도 매너 있게 피력해보는 것은 어떨까요? 
누구에게나 사랑받는 당신의 생각이라면 분명 잘 통할 거예요.'''

        result_message3 = '''당신은 쿨~ 한 성격을 가진 사람! 크게 목소리를 높이지는 않지만 할 말은 조곤조곤 꼭 내뱉는 성격이에요. 
정해진 결과에 미련을 갖지도 않고, 다른 이의 의견은 경청하기에 갈등을 일으키지는 않지만, 조용하고 칼같이 일을 끝맺는 모습에 주변인들의 오해를 살 수도 있어요. 
당신의 속에 잠든 시원하고 멋진 속내가 오해받지 않도록, 가끔은 이성보다 감정에 귀를 기울여 보는 것은 어떨까요?'''

        result_message4 = '''당신은 쿨~ 한 성격을 가진 사람! 당신은 사람들의 말에 귀를 많이 기울이는 편이지만 그러면서도 할 말은 하는 타입이에요. 
논쟁 중에는 자신의 의견을 피력하면서도 결과에 대해 뒤끝은 없는 성격이에요. 이성보다는 감정에 조금 더 충실한 사람이라 상대방의 진심 어린 호소 앞에서는 판단력이 흐려질 수 있어요. 
또한 고민을 털어놓는 친구가 이해되지 않아도 공감하려 노력해요.'''

        result_message5 = '''당신은 똑부러지는 성격을 가진 사람! 평소에는 말이 없지만 자기 주장이 강해서 자신이 옳다고 생각하는 부분이 부정되면 그 순간부터는 언변의 마술사! 
주변에서 똑똑하다는 말을 많이 듣기도 하지만 감정표현이 조금 부족한 편이에요. 그래서 친구가 당신에게 고민을 털어놓을 때, 공감해보려 노력하지만 겉으로 표현이 되지 않아서 곤란할 때가 있어요! 
이 때문에 상대방이 오해할 수 있으니 가까운 사람에게 조금만 더 표현을 해보는 건 어떨까요?'''

        result_message6 = '''당신은 똑부러지는 성격을 가진 사람! 당신은 고집이 센 편이지만 의견을 굽혀야 할 땐 굽힐 줄 아는 사람이에요. 
상황에 대한 판단을 유연하게 잘 하며 감정보다는 이성에 충실한 편이라 주변으로부터 똑부러진다는 말을 많이 들어요. 겉으로는 상대방의 입장에서 공감하려 노력하지만 속으로는 잘 이해되지 않아서 곤란할 때가 있어요. 
자기 주장이 나름 강한 편이라 회의에서 내린 결정이 자신의 의견과 다른 경우 약간의 뒤끝이 있지만 조금만 더 유연해져 보아요!'''

        result_message7 = '''당신은 차가운 매력의 소유자! 당신은 낯을 많이 가리고 사람들 사이에서 튀는 걸 좋아하진 않아요. 하지만 자기 주장이 굉장히 강한 편이라서 할 말은 해야 직성이 풀리는 스타일! 
쉽게 고집을 꺾지 않아서 때로는 주변의 미움을 살 수도 있으니 주의하세요! 또한 자신만의 주관과 원칙이 뚜렷해서 누가 자신의 일에 관여하는 것을 싫어해요. 누군가와 함께 일을 하는 것보다 혼자 하는 게 더 편하다고 생각하죠. 
하지만 추진력과 책임감이 강하며 현실적이기에 혼자서도 잘하는 당신은 정말 매력적이네요!'''

        result_message8 = '''당신은 당차고 현실적인 사람! 당신은 사람들과 이야기를 나눌 때 자기 주장을 강하게 내세우는 편이에요. 쉽게 고집을 꺾지 않아서 때로는 주변의 미움을 살 수도 있으니 주의하세요! 
감정적이기보다 이성적인 당신은 상황을 냉철하게 판단하고 결단력이 있게 행동하는 편이에요. 또한 현실적인 사람이어서 문제가 생기면 좋은 해결책을 제시해준답니다. 
한 번 아니라고 생각되면 끝까지 맞서 싸워서 정의를 되찾으려고 하는 성격 덕에 손해는 거의 보지 않고 사는 편이에요!'''

        if score1 < 25:
            in_out = '내향'
        elif score1 >= 25:
            in_out = '외향' #외향/내향 관련 점수 범위에 따라 변수 설정
    
        if score2 < 16:
            season = '봄'
        elif score2 < 24:
            season = '여름'
        elif score2 < 32:
            season = '가을'
        elif score2 <= 40:
            season = '겨울' #계절 관련 점수 범위에 따라 변수 설정

        canvas = Canvas(test, width=394, height=700)
        canvas.pack()

        label_expl = Label(test, text = '', font=('Nanum Gothic',14), wraplength=290, height=13, justify='left')
        label_expl.place(x=200, y=456, anchor='center')
            
        #결과에 따라 내용 출력
        if in_out == '내향' and season == '봄':
            canvas.create_image(0,0,image=result_image1,anchor='nw')
            label_expl.config(text = result_message1)
        elif in_out == '외향' and season == '봄':
            canvas.create_image(0,0,image=result_image2,anchor='nw')
            label_expl.config(text = result_message2)
        elif in_out == '내향' and season == '여름':
            canvas.create_image(0,0,image=result_image3,anchor='nw')
            label_expl.config(text = result_message3)
        elif in_out == '외향' and season == '여름':
            canvas.create_image(0,0,image=result_image4,anchor='nw')
            label_expl.config(text = result_message4)
        elif in_out == '내향' and season == '가을':
            canvas.create_image(0,0,image=result_image5,anchor='nw')
            label_expl.config(text = result_message5)
        elif in_out == '외향' and season == '가을':
            canvas.create_image(0,0,image=result_image6,anchor='nw')
            label_expl.config(text = result_message6)
        elif in_out == '내향' and season == '겨울':
            canvas.create_image(0,0,image=result_image7,anchor='nw')
            label_expl.config(text = result_message7)
        elif in_out == '외향' and season == '겨울':
            canvas.create_image(0,0,image=result_image8,anchor='nw')
            label_expl.config(text = result_message8)

        quit_button = Button(test, text='종료', font=('Nanum Gothic', 20), relief='sunken', width=6, height=2, fg='maroon', command=test.destroy)
        quit_button.place(x=266, y=613, anchor='center') #종료 버튼

        restart_button = Button(test, text='다시하기', font=('Nanum Gothic', 20), relief='sunken', width=8, height=2, fg='maroon', command=Restart)
        restart_button.place(x=133, y=613, anchor='center') #재시작 버튼

    else: #질문이 두 개 이상 남았을 경우
        grade = score.get()
        grade = int(grade) #선택 버튼값 받아서 정수로 변환

        if qus in question1:
            score1 += grade
            question1.remove(qus) #외향/내향 관련 질문일 경우 외향/내향 관련 점수에 선택 버튼값 더하기
        elif qus in question2:
            score2 += grade
            question2.remove(qus) #계절 성격 관련 질문일 경우 계절 성격 관련 점수에 선택 버튼값 더하기
            
        question.remove(qus)

        if score1_how == 8:
            qus = random.choice(question2)
            label1.config(text=qus)
        elif score2_how == 8:
            qus = random.choice(question1)
            label1.config(text=qus)
        else:
            qus = random.choice(question)
            label1.config(text=qus)
            
        if qus in question1:
            score1_how += 1
        elif qus in question2:
            score2_how += 1
            
        if score1_how == 8 and score2_how == 8:
            button_go.config(text='결과는?', width=7) #이전 질문 제거하고 새롭게 랜덤 택일한 질문 출력하고 관련 질문에 따라 횟수 추가


def Restart(): #재시작 함수

    global test
    global label1
    global button_start
    global result_image1
    global result_image2
    global result_image3
    global result_image4
    global result_image5
    global result_image6
    global result_image7
    global result_image8

    test.destroy()

    test = Tk()

    test.title('성격 검사 프로그램')
    test.geometry('394x700+500+50')
    test.resizable(1, 1) #창 설정

    result_image1 = PhotoImage(file='in_spring.png')
    result_image2 = PhotoImage(file='out_spring.png')
    result_image3 = PhotoImage(file='in_summer.png')
    result_image4 = PhotoImage(file='out_summer.png')
    result_image5 = PhotoImage(file='in_fall.png')
    result_image6 = PhotoImage(file='out_fall.png')
    result_image7 = PhotoImage(file='in_winter.png')
    result_image8 = PhotoImage(file='out_winter.png')

    start_image = PhotoImage(file='startimg.png')
    label1 = Label(test, image=start_image, text='', font=('Nanum Gothic',18), wraplength=370)
    label1.pack() #시작 이미지

    button_start = Button(test, text='start', font=('Nanum Gothic',30), relief='sunken', fg='maroon', width=10, height=2, command=Start)
    button_start.place(x=0, y=570, relx=0.5, anchor='center') #시작 버튼

    test.mainloop()

from tkinter import *
import random

test = Tk()

test.title('성격 계절 테스트')
test.geometry('394x700+500+50')
test.resizable(1, 1) #창 설정

result_image1 = PhotoImage(file='in_spring.png')
result_image2 = PhotoImage(file='out_spring.png')
result_image3 = PhotoImage(file='in_summer.png')
result_image4 = PhotoImage(file='out_summer.png')
result_image5 = PhotoImage(file='in_fall.png')
result_image6 = PhotoImage(file='out_fall.png')
result_image7 = PhotoImage(file='in_winter.png')
result_image8 = PhotoImage(file='out_winter.png')

start_image = PhotoImage(file='startimg.png')
label1 = Label(test, image=start_image, text='', font=('Nanum Gothic',18), wraplength=370)
label1.pack() #시작 이미지

button_start = Button(test, text='start', font=('Nanum Gothic',30), relief='sunken', fg='maroon', width=10, height=2, command=Start)
button_start.place(x=0, y=570, relx=0.5, anchor='center') #시작 버튼

test.mainloop()